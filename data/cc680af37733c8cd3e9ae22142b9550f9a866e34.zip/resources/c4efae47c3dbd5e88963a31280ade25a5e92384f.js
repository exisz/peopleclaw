// <stdin>
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
function Client({ onSubmit }) {
  const [file, setFile] = useState(null);
  const [targetFace, setTargetFace] = useState("");
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [error, setError] = useState(null);
  const handleFile = (e) => {
    const f = e.target.files?.[0];
    if (!f) return;
    const reader = new FileReader();
    reader.onload = () => setFile(reader.result);
    reader.readAsDataURL(f);
  };
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const res = onSubmit ? await onSubmit({ imageUrl: file, targetFace }) : null;
      if (res) setResult(res);
    } catch (err) {
      setError(err.message ?? "\u5904\u7406\u5931\u8D25");
    }
    setLoading(false);
  };
  if (result) return /* @__PURE__ */ jsxs("div", { style: { padding: "1rem", fontFamily: "system-ui" }, children: [
    /* @__PURE__ */ jsx("h2", { children: "\u{1F3AD} \u5904\u7406\u5B8C\u6210" }),
    result.swappedUrl && /* @__PURE__ */ jsx("img", { src: result.swappedUrl, alt: "swapped", "data-testid": "face-swap-result", style: { width: 240, borderRadius: 8, marginTop: "0.5rem" } }),
    /* @__PURE__ */ jsxs("p", { style: { color: "#666", fontSize: "0.875rem", marginTop: "0.5rem" }, children: [
      "provider: ",
      result.provider ?? "unknown"
    ] }),
    /* @__PURE__ */ jsx("button", { onClick: () => {
      setResult(null);
      setFile(null);
    }, style: { marginTop: "0.5rem", padding: "0.25rem 0.75rem", border: "1px solid #ccc", borderRadius: 4, cursor: "pointer" }, children: "\u91CD\u65B0\u5F00\u59CB" })
  ] });
  return /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, style: { padding: "1rem", fontFamily: "system-ui", display: "flex", flexDirection: "column", gap: "0.75rem", maxWidth: 360 }, children: [
    /* @__PURE__ */ jsx("h2", { children: "\u{1F3AD} AI \u6362\u8138 - \u4E0A\u4F20" }),
    /* @__PURE__ */ jsx("label", { style: { fontSize: "0.875rem", fontWeight: 500 }, children: "\u539F\u59CB\u56FE\u7247" }),
    /* @__PURE__ */ jsx("input", { type: "file", accept: "image/*", onChange: handleFile, "data-testid": "face-swap-file-input" }),
    file && /* @__PURE__ */ jsx("img", { src: file, alt: "preview", style: { width: 160, borderRadius: 8 } }),
    /* @__PURE__ */ jsx("label", { style: { fontSize: "0.875rem", fontWeight: 500 }, children: "\u76EE\u6807\u8138\u578B (\u53EF\u9009)" }),
    /* @__PURE__ */ jsx(
      "input",
      {
        name: "targetFace",
        placeholder: "e.g. celebrity name",
        value: targetFace,
        onChange: (e) => setTargetFace(e.target.value),
        style: { padding: "0.5rem", border: "1px solid #ccc", borderRadius: 4 }
      }
    ),
    error && /* @__PURE__ */ jsx("p", { style: { color: "red", fontSize: "0.875rem" }, children: error }),
    /* @__PURE__ */ jsx(
      "button",
      {
        type: "submit",
        disabled: !file || loading,
        "data-testid": "face-swap-submit-btn",
        style: { padding: "0.5rem 1rem", background: "#0070f3", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", opacity: file && !loading ? 1 : 0.5 },
        children: loading ? "\u5904\u7406\u4E2D..." : "\u63D0\u4EA4\u6362\u8138"
      }
    )
  ] });
}
var stdin_default = Client;
export {
  Client,
  stdin_default as default
};
