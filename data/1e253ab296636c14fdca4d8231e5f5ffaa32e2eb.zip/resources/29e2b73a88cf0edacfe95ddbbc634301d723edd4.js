// <stdin>
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
function Client({ onSubmit }) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [company, setCompany] = useState("");
  const [tags, setTags] = useState("");
  const [loading, setLoading] = useState(false);
  const [saved, setSaved] = useState(null);
  const [error, setError] = useState(null);
  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!name) return;
    setLoading(true);
    setError(null);
    try {
      const res = onSubmit ? await onSubmit({ name, email, phone, company, tags }) : null;
      if (res) setSaved(res);
      setName("");
      setEmail("");
      setPhone("");
      setCompany("");
      setTags("");
    } catch (err) {
      setError(err?.message ?? "\u4FDD\u5B58\u5931\u8D25");
    }
    setLoading(false);
  };
  return /* @__PURE__ */ jsxs("form", { onSubmit: handleSubmit, "data-testid": "crm-contact-form", style: { padding: "1rem", fontFamily: "system-ui", display: "flex", flexDirection: "column", gap: "0.5rem", maxWidth: 360 }, children: [
    /* @__PURE__ */ jsx("h2", { children: "\u{1F464} \u65B0\u589E\u8054\u7CFB\u4EBA" }),
    /* @__PURE__ */ jsx("input", { "data-testid": "crm-contact-name", placeholder: "\u59D3\u540D", value: name, onChange: (e) => setName(e.target.value), style: { padding: "0.4rem", border: "1px solid #ccc", borderRadius: 4 } }),
    /* @__PURE__ */ jsx("input", { "data-testid": "crm-contact-email", placeholder: "\u90AE\u7BB1", value: email, onChange: (e) => setEmail(e.target.value), style: { padding: "0.4rem", border: "1px solid #ccc", borderRadius: 4 } }),
    /* @__PURE__ */ jsx("input", { "data-testid": "crm-contact-phone", placeholder: "\u7535\u8BDD", value: phone, onChange: (e) => setPhone(e.target.value), style: { padding: "0.4rem", border: "1px solid #ccc", borderRadius: 4 } }),
    /* @__PURE__ */ jsx("input", { "data-testid": "crm-contact-company", placeholder: "\u516C\u53F8", value: company, onChange: (e) => setCompany(e.target.value), style: { padding: "0.4rem", border: "1px solid #ccc", borderRadius: 4 } }),
    /* @__PURE__ */ jsx("input", { "data-testid": "crm-contact-tags", placeholder: "\u6807\u7B7E (\u9017\u53F7\u5206\u9694)", value: tags, onChange: (e) => setTags(e.target.value), style: { padding: "0.4rem", border: "1px solid #ccc", borderRadius: 4 } }),
    error && /* @__PURE__ */ jsx("p", { style: { color: "red", fontSize: "0.85rem" }, children: error }),
    saved && saved.id && /* @__PURE__ */ jsxs("p", { "data-testid": "crm-contact-saved", style: { color: "#0a7c2a", fontSize: "0.85rem" }, children: [
      "\u5DF2\u4FDD\u5B58\uFF1A",
      saved.name
    ] }),
    /* @__PURE__ */ jsx("button", { "data-testid": "crm-contact-submit", type: "submit", disabled: !name || loading, style: { padding: "0.5rem 1rem", background: "#0070f3", color: "#fff", border: "none", borderRadius: 4, cursor: "pointer", opacity: name && !loading ? 1 : 0.5 }, children: loading ? "\u4FDD\u5B58\u4E2D..." : "\u4FDD\u5B58\u8054\u7CFB\u4EBA" })
  ] });
}
var stdin_default = Client;
export {
  Client,
  stdin_default as default
};
