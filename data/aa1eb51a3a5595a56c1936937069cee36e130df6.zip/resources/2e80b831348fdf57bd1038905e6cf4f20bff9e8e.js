// <stdin>
import { useState, useEffect, createElement } from "react";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
var Client = ({ data, refresh }) => {
  if (data && data.ok === false) {
    const isSetup = data.error === "NEED_SETUP";
    return /* @__PURE__ */ jsxs("div", { "data-testid": "shopify-list-state", "data-state": isSetup ? "need-setup" : "error", style: { padding: "1.5rem", fontFamily: "system-ui", maxWidth: 480, margin: "0 auto", textAlign: "center" }, children: [
      /* @__PURE__ */ jsx("h2", { children: "\u{1F6CD}\uFE0F Shopify \u5546\u54C1\u5217\u8868" }),
      isSetup ? /* @__PURE__ */ jsxs(Fragment, { children: [
        /* @__PURE__ */ jsx("p", { style: { color: "#444", margin: "1rem 0" }, children: "\u9700\u8981\u5148\u914D\u7F6E Shopify \u51ED\u8BC1\u624D\u80FD\u62C9\u53D6\u5546\u54C1\u3002" }),
        /* @__PURE__ */ jsx(
          "button",
          {
            "data-testid": "shopify-setup-cta",
            onClick: () => {
              try {
                window.parent.postMessage({ type: "open-secrets-tab" }, "*");
              } catch {
              }
            },
            style: { padding: "0.75rem 1.5rem", background: "#0070f3", color: "#fff", border: "none", borderRadius: 6, fontSize: "1rem", cursor: "pointer" },
            children: "\u{1F510} \u914D\u7F6E Shopify (\u53BB Secrets tab)"
          }
        ),
        /* @__PURE__ */ jsxs("p", { style: { color: "#888", fontSize: "0.85rem", marginTop: "1rem" }, children: [
          "\u5728 \u{1F510} Secrets tab \u914D\u7F6E ",
          /* @__PURE__ */ jsx("code", { children: "SHOPIFY_ADMIN_TOKEN" }),
          " \u548C ",
          /* @__PURE__ */ jsx("code", { children: "SHOPIFY_SHOP_DOMAIN" }),
          "\uFF0C\u5237\u65B0\u5373\u53EF\u3002"
        ] })
      ] }) : /* @__PURE__ */ jsxs("p", { style: { color: "#c00", margin: "1rem 0" }, children: [
        "\u8C03\u7528 Shopify \u5931\u8D25\uFF1A",
        data.error,
        data.message ? " \u2014 " + data.message : ""
      ] })
    ] });
  }
  const products = data && data.products || [];
  return /* @__PURE__ */ jsxs("div", { "data-testid": "shopify-list-state", "data-state": "ok", style: { padding: "1rem", fontFamily: "system-ui" }, children: [
    /* @__PURE__ */ jsx("h2", { children: "\u{1F6CD}\uFE0F Shopify \u5546\u54C1\u5217\u8868" }),
    products.length === 0 && /* @__PURE__ */ jsx("p", { children: "\u5546\u54C1\u5217\u8868\u4E3A\u7A7A" }),
    /* @__PURE__ */ jsx("div", { style: { display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))", gap: "1rem" }, children: products.map((p) => /* @__PURE__ */ jsxs("div", { style: { border: "1px solid #eee", borderRadius: 8, padding: "0.75rem", textAlign: "center" }, children: [
      p.image && /* @__PURE__ */ jsx("img", { src: p.image, alt: p.title, style: { width: "100%", height: 120, objectFit: "cover", borderRadius: 4 } }),
      /* @__PURE__ */ jsx("p", { style: { fontWeight: 600, fontSize: "0.875rem", marginTop: "0.5rem" }, children: p.title }),
      /* @__PURE__ */ jsxs("p", { style: { color: "#666", fontSize: "0.75rem" }, children: [
        "$",
        p.price
      ] })
    ] }, p.id)) })
  ] });
};
function FullstackWrapper() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const refresh = () => {
    setLoading(true);
    fetch("/api/components/cmot6xnxi0009l104ih4jl6hy/server").then((r) => r.json()).then((d) => {
      setData(d);
      setLoading(false);
    }).catch(() => setLoading(false));
  };
  useEffect(() => {
    refresh();
  }, []);
  if (loading && !data) return createElement("div", null, "Loading...");
  return createElement(Client, { data, refresh });
}
export {
  Client,
  FullstackWrapper as default
};
